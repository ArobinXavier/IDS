#!/bin/bash

echo "🚀 Starting environment setup..."

# ---- 1. System dependencies (FFmpeg) ----
# echo "📦 Installing FFmpeg..."
# sudo apt update && sudo apt install -y ffmpeg

# ---- 2. Python environment setup ----
echo "🐍 Creating virtual environment..."
python3 -m venv venv --system-site-packages
source venv/bin/activate 

echo "📦 Installing Python requirements..."
# pip install --upgrade pip
pip install -r requirements.txt