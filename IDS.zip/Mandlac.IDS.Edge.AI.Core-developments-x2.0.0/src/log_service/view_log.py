import os
import tempfile
import datetime
import re
from azure.storage.blob import BlobServiceClient, ContentSettings

from utility_service import LOG_FILE, ERROR_LOG_FILE
from config_service import load_default_config
from utility_service import Globals

# Load config
config = load_default_config()
AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
AZURE_CONTAINER_NAME = config.get('azure_container_name', '')


def upload_to_azure(file_path, blob_name):
    """Upload file to Azure Blob Storage."""
    blob_service = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
    blob_client = blob_service.get_blob_client(
        container=AZURE_CONTAINER_NAME,
        blob=blob_name
    )

    with open(file_path, "rb") as data:
        blob_client.upload_blob(
            data,
            overwrite=True,
            content_settings=ContentSettings(content_type='text/plain')
        )

    print(f"Uploaded to Azure: {blob_client.url}")
    return blob_client.url


def filter_logs_by_time(log_text, t_from, t_to):
    """
    Filter log lines where timestamp falls inside the given range.
    Real log format:
    2025-11-20T15:59:25+05:30 message....
    """

    filtered = []

    # Regex for ISO timestamp WITH timezone (your real log format)
    pattern = r"^([0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\+[0-9]{2}:[0-9]{2})?)"

    # Convert incoming timestamps to datetime
    t_from_dt = datetime.datetime.fromisoformat(t_from)
    t_to_dt = datetime.datetime.fromisoformat(t_to)

    for line in log_text.splitlines():
        m = re.match(pattern, line)
        if not m:
            continue

        log_ts = datetime.datetime.fromisoformat(m.group(1))

        if t_from_dt <= log_ts <= t_to_dt:
            filtered.append(line)

    return "\n".join(filtered)


def process_log(file_path, suffix, t_from, t_to):
    """Read log → filter → upload temp file → return blob URL"""

    try:
        with open(file_path, "r", errors="ignore") as f:
            logs = f.read()
    except FileNotFoundError:
        print(f"Not found: {file_path}")
        return None

    filtered = filter_logs_by_time(logs, t_from, t_to)

    if not filtered.strip():
        print(f"No matching logs in range for: {file_path}")
        return None

    # Temp file for uploading
    with tempfile.NamedTemporaryFile(delete=False, suffix=".log") as tmp:
        tmp.write(filtered.encode("utf-8"))
        temp_path = tmp.name

    print(f"Prepared filtered log temp file: {temp_path}")

    # Generate blob path
    device_id = Globals.MAC_ADDRESS
    timestamp = datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S')
    blob_name = f"{device_id}/{device_id}_{suffix}_{timestamp}.log"

    url = upload_to_azure(temp_path, blob_name)

    # Remove temp file only (NOT original logs)
    os.remove(temp_path)

    return url


def view_log(request_payload):
    """
    Time-filtered log uploader. Supports:
    1) fromDate + toDate
    2) logDays
    """

    file_urls = []

    # --- NEW: logDays support ---
    log_days = request_payload.get("logDays")

    if log_days:
        try:
            days = int(log_days)
        except:
            return {
                "status": "NOK",
                "message": "Invalid 'logDays' value (must be number)"
            }

        now = datetime.datetime.now().astimezone()
        t_to = now.isoformat(timespec="seconds")
        t_from = (now - datetime.timedelta(days=days)).isoformat(timespec="seconds")

    else:
        t_from = request_payload.get("fromDate")
        t_to = request_payload.get("toDate")

        if not t_from or not t_to:
            return {
                "status": "NOK",
                "message": "Missing 'fromDate' or 'toDate'"
            }

    # Process logs
    main_url = process_log(LOG_FILE, "main", t_from, t_to)
    if main_url:
        file_urls.append(main_url)

    error_url = process_log(ERROR_LOG_FILE, "error", t_from, t_to)
    if error_url:
        file_urls.append(error_url)

    return {
        "status": "OK",
        "file_urls": file_urls
    }
 