import threading
import sys
import time
import traceback
from collections import deque

from utility_service import get_device_timezone, get_eth0_mac, Globals
Globals.MAC_ADDRESS = get_eth0_mac()
print(f"[INFO] Device MAC Address: {Globals.MAC_ADDRESS}")

from camera_service import get_all_camera_streams, build_pipeline_string
from mqtt_service import start_mqtt_client
from config_service import get_config
from ml_service import launch_pipeline, decision_worker0, decision_worker1, decision_worker2, download_model_from_api, capture_frame_worker0, capture_frame_worker1, capture_frame_worker2, upload_event_watch_worker, fast_upload_worker, video_upload_worker
from offline_service import siren_worker
from offline_service import relay_worker

print(Globals.detection_queue0)

def unknown_method(idx):
   print(f'Unknown method, idx: {idx}') 
    
method_dispatch = {
    'decision_worker0': decision_worker0,
    'decision_worker1': decision_worker1,
    'decision_worker2': decision_worker2,
    'capture_frame_worker0': capture_frame_worker0,
    'capture_frame_worker1': capture_frame_worker1,
    'capture_frame_worker2': capture_frame_worker2
}

def main():
    pipeline_str, cam_keys, cam_payload = None, None, None
    
    # siren_thread = threading.Thread(target=siren_worker, daemon=True)
    # siren_thread.start()
    # print("[INFO] Siren worker started")
    
    siren_thread = threading.Thread(target=relay_worker, daemon=True)
    siren_thread.start()
    print("[INFO] Relay worker started")
    
    # Start MQTT client in a background thread
    mqtt_thread = threading.Thread(target=start_mqtt_client, daemon=True)
    
    try:
        print("[INFO] Starting MQTT client in background...")
        mqtt_thread.start()

        print("[INFO] Getting device timezone...")
        timezone = get_device_timezone()
        print(f"[INFO] Device timezone: {timezone}")
    except Exception as e:
        print(f"[ERROR] MQTT/Timezone initialization failed: {e}")
        
    download_model_from_api()

    # Retry until pipeline is built correctly
    print("[INFO] Waiting for pipeline configuration...")
    
    private_location = get_config(-1)
    print('private_location', private_location)
    if private_location is not None:
        Globals.prepare_private_storage_config(private_location)

    while not (pipeline_str and cam_keys and cam_payload):
        try:
            pipeline_str, cam_keys, cam_payload = build_pipeline_string()

            if not pipeline_str or not cam_keys or not cam_payload:
                raise ValueError("Incomplete pipeline data")

        except Exception as e:
            print(f"[WARN] build_pipeline_string() failed or returned invalid data: {e}")
            time.sleep(2)  # Retry delay
        else:
            print("[INFO] Pipeline configuration built successfully.")

    print(f"[INFO] Building streaming completed")

    for idx, (cam_key, payload) in enumerate(cam_payload.items()):
        decision_worker_handler = method_dispatch.get(f'decision_worker{idx}', unknown_method)
        capture_frame_worker_handler = method_dispatch.get(f'capture_frame_worker{idx}', unknown_method)
        Globals.cam_key_idx_map[cam_key] = idx

        Globals.prepare_service_config(idx, cam_key, payload)

        decision_thread = threading.Thread(
            target=decision_worker_handler,
            args=(cam_key,),
            daemon=True
        )
        decision_thread.start()

        capture_frame_thread = threading.Thread(
            target=capture_frame_worker_handler,
            daemon=True
        )
        capture_frame_thread.start()
        
        
    upload_event_watch_thread = threading.Thread(
        target=upload_event_watch_worker,
        daemon=True
    )
    upload_event_watch_thread.start()
        
    fast_upload_thread = threading.Thread(
        target=fast_upload_worker,
        daemon=True
    )
    fast_upload_thread.start()
    
    video_upload_thread = threading.Thread(
        target=video_upload_worker,
        daemon=True
    )
    video_upload_thread.start()
        
    print("[INFO] Launching intrusion detection pipeline...")
    launch_pipeline(pipeline_str, cam_keys)

if __name__ == "__main__":
    main()