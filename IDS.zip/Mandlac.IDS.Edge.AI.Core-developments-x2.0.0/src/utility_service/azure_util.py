import concurrent.futures
import os
import imageio
from datetime import datetime
from azure.storage.blob import BlobServiceClient

def upload_file(local_file_path, blob_name):
    try:
        from config_service import load_default_config
        # Default Configuration
        config = load_default_config()

        AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
        CONTAINER_NAME = config.get('azure_container_name', '')
        blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
        container_client = blob_service_client.get_container_client(CONTAINER_NAME)

        with open(local_file_path, "rb") as data:
            container_client.upload_blob(name=blob_name, data=data, overwrite=True)

        url = f"https://{blob_service_client.account_name}.blob.core.windows.net/{CONTAINER_NAME}/{blob_name}"
        print(f"[INFO] Uploaded {blob_name} to Azure Blob Storage.")
        print(f"[INFO] Blob URL: {url}")
        return url
    except Exception as e:
        print(f"[ERROR] Failed to upload to Azure Blob: {e}")
        return None
    

def upload_multiple_files(file_paths, euid):
    uploaded_urls = []

    def upload_single_file(file_path):
        from config_service import load_default_config
        # Default Configuration
        config = load_default_config()

        AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
        CONTAINER_NAME = config.get('azure_container_name', '')

        file_name = os.path.basename(file_path)
        blob_path = f"{euid}/{file_name}"

        blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_path)

        with open(file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)

        blob_url = blob_client.url
        print(f"✅ Uploaded: {blob_url}")
        return blob_url

    # Use ThreadPoolExecutor for parallel uploads
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(upload_single_file, file_path) for file_path in file_paths]

        for future in concurrent.futures.as_completed(futures):
            try:
                uploaded_url = future.result()
                uploaded_urls.append(uploaded_url)
            except Exception as e:
                print(f"❌ Upload failed for a file: {e}")

    return uploaded_urls

def upload_images_as_gif(file_paths, directory_path, euid):
    try:
        from config_service import load_default_config

        # Load Azure Blob config
        config = load_default_config()
        AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
        CONTAINER_NAME = config.get('azure_container_name', '')

        # Output GIF file path
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        gif_file_name = f"{euid}_{timestamp}.gif"
        gif_file_path = os.path.join(directory_path, gif_file_name)  # or any temp directory

        # Read images and create GIF
        images = []
        for path in file_paths:
            try:
                images.append(imageio.imread(path))
            except Exception as e:
                print(f"⚠️ Failed to read image {path}: {e}")

        if not images:
            raise Exception("No valid images to create GIF.")

        imageio.mimsave(gif_file_path, images, duration=0.5, loop=0)  # 0.5s per frame
        print(f"🎞️ GIF created at: {gif_file_path}")

        # Upload GIF to Azure
        blob_path = f"{euid}/{gif_file_name}"
        blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_path)

        with open(gif_file_path, "rb") as data:
            blob_client.upload_blob(data, overwrite=True)

        blob_url = blob_client.url
        print(f"✅ Uploaded GIF: {blob_url}")

        return [blob_url]  # Keeping return type consistent as a list

    except Exception as e:
        print(f"❌ Error in upload_images_as_gif: {e}")
        return []