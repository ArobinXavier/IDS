from collections import deque
from queue import Queue
from enums import SirenAction
from enums import RelayAction
from tzlocal import get_localzone


FRAME_RATE = 20
RECORDING_FPS = 30
PREV_HOLD_SECONDS = 5
POST_EVENT_SECONDS = 5 
PREV_HOLD_FRAMES = RECORDING_FPS * PREV_HOLD_SECONDS # ~30 FPS × 5s

class Globals:
    
    MAC_ADDRESS = ""
    MIN_CONFIDENCE = 0.50
    MIN_OCCURRENCES = 2
    MIN_OCCURRENCES_BETWEEN_TWO_BUCKETS = 1
    WINDOW_MS = 500
    EMPTY_BUCKET_GRACE = 3
    
    PREV_HOLD_SECONDS = PREV_HOLD_SECONDS
    POST_EVENT_SECONDS = POST_EVENT_SECONDS
    
    all_labels_set0 = set()
    all_labels_set1 = set()
    all_labels_set2 = set()
    
    scene_map0 = {}
    scene_map1 = {}
    scene_map2 = {}
    
    schedule_map0 = {}
    schedule_map1 = {}
    schedule_map2 = {}

    detection_queue0 = deque(maxlen=FRAME_RATE)
    detection_queue1 = deque(maxlen=FRAME_RATE)
    detection_queue2 = deque(maxlen=FRAME_RATE)

    capture_frame_queue0 = Queue()
    capture_frame_queue1 = Queue()
    capture_frame_queue2 = Queue()
    
    pre_event_frames0 = deque(maxlen=PREV_HOLD_FRAMES)
    pre_event_frames1 = deque(maxlen=PREV_HOLD_FRAMES)
    pre_event_frames2 = deque(maxlen=PREV_HOLD_FRAMES)
    
    ongoing_post_events0 = {}
    ongoing_post_events1 = {}
    ongoing_post_events2 = {}
    
    frame_hold_queue0 = deque(maxlen=1)
    frame_hold_queue1 = deque(maxlen=1)
    frame_hold_queue2 = deque(maxlen=1)
    
    fast_upload_queue = Queue()
    full_event_upload_queue = Queue()
    
    cam_key_idx_map = {}
    device_config_map0 = {}
    device_config_map1 = {}
    device_config_map2 = {}
    cam_mode_map = {}

    device_timezone = get_localzone()
    
    siren_queue = Queue()
    relay_queue = Queue()
    last_mount_config = None
    is_internal_storage = True
    file_server_host = None

    @staticmethod
    def prepare_private_storage_config(payload):
        print('prepare_private_storage_config', payload)
        Globals.last_mount_config = payload
        Globals.is_internal_storage = payload.get("isInternalStorage")
        Globals.file_server_host = payload.get("hostIpAddress","")

    @staticmethod
    def prepare_service_config(idx, device_id, payload):
        global cam_key_idx_map
        """
        Extracts label and scene configuration from service payload
        and updates all_labels_set{idx} and scene_map{idx}.
        """

        print(f"prepare_service_config ::: {device_id}")
        print(f"prepare_service_config_payload ::: {payload}")
        if idx == -1:
            # Get index from cam_key_idx_map using device_id
            idx = cam_key_idx_map.get(device_id)
        if idx is None:
            raise ValueError(f"Device ID '{device_id}' not found in cam_key_idx_map.")

        # Dynamically get the per-index label set and scene map
        all_labels_set = getattr(Globals, f"all_labels_set{idx}")
        scene_map = getattr(Globals, f"scene_map{idx}")
        schedule_map = getattr(Globals, f"schedule_map{idx}")
        device_config_map = getattr(Globals, f"device_config_map{idx}")
        cam_mode_map = getattr(Globals, f"cam_mode_map")
        
        rtsp_url, statusId = payload.get("rtsp_url", ""), payload.get("statusId")
        
        device_config_map[device_id] = rtsp_url
          
        cam_mode_map[device_id] = statusId

        services = payload.get("services", [])

        for service in services:
            # Normalize labels to lowercase
            labels = [label.lower() for label in service.get("labels", [])]

            # Update global label set
            all_labels_set.update(labels)

            # Update scene mapping
            sceneInstance_id = service.get("sceneInstanceId")
            if sceneInstance_id is not None:
                scene_map[sceneInstance_id] = labels
                
            print(f'service.get("schedulers", []): {service.get("schedulers", [])}')
                
            raw_boundary = service.get("boundary", None)
            if raw_boundary is not None:
                boundary = {
                    'x1': int(raw_boundary['x1']),
                    'x2': int(raw_boundary['x2']),
                    'y1': int(raw_boundary['y1']),
                    'y2': int(raw_boundary['y2'])
                }
            else:
                boundary = None

            # --- Siren Configuration ---
            siren_ip = payload.get("sirenIpAddress", "")
            siren_port = payload.get("sirenPort", "")
            is_enable_siren = payload.get("isEnableSiren", False)
                
            areaName = payload.get("areaName", "")
            floorType = payload.get("floorType", "")
            deviceName = payload.get("deviceName", "")
            sceneName = service.get("sceneName", "")
                
            schedule_map[sceneInstance_id] = (
                service.get("schedulers", []),
                boundary,
                areaName,
                floorType,
                deviceName,
                sceneName,
                siren_ip,
                siren_port,
                is_enable_siren
            )

