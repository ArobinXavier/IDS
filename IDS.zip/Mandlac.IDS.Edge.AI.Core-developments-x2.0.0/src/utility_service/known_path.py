import os

OPT_DIR = '/opt'
TMP_DIR = '/tmp'
SERVICE_DIR = '/etc/systemd/system'
VAR_DIR = '/var'
VAR_DATA_DIR = f'{VAR_DIR}/lib/mandlacx/database/x'
VAR_CAPTURE_IMAGE_DIR = f'{VAR_DIR}/lib/mandlacx/capture_image/x'
VAR_MODEL_DIR = f'{VAR_DATA_DIR}/model'
SQL_LITE_FILE_NAME = 'config.db'
SQL_LITE_FILE_PATH = os.path.join(VAR_DATA_DIR, SQL_LITE_FILE_NAME) 
LOG_FILE = '/var/log/mandlacx-x.log'
ERROR_LOG_FILE = '/var/log/mandlacx-x-error.log' 