import os
import sys
import time
import threading
import io
import netifaces
from tzlocal import get_localzone
import pytz
import subprocess
import tempfile


def restart_app(payload):
    print(f"Restarting the application with payload: {payload}")
    # Logic for restarting the app
    python_executable = sys.executable
    script_path = os.path.abspath(sys.argv[0])
    os.execv(python_executable, [python_executable, script_path])

def schedule_restart(payload, delay=5):
    def delayed_restart():
        print(f"[INFO] Restart scheduled in {delay} seconds...")
        time.sleep(delay)
        restart_app(payload)
    
    threading.Thread(target=delayed_restart, daemon=True).start()

def reboot(payload):
    print(f"Rebooting the system with payload: {payload}")
    # Logic for rebooting the system
    os.system("sudo reboot")

def get_eth0_mac(interval=5):
    """
    Blocks until eth0 has a valid IPv4 and MAC.
    interval = seconds to wait between retries.
    """
    print("Waiting for eth0 to have a valid MAC address...")
    while True:
        if "eth0" in netifaces.interfaces():
            addrs = netifaces.ifaddresses("eth0")
            if netifaces.AF_INET in addrs and netifaces.AF_LINK in addrs:
                mac = addrs[netifaces.AF_LINK][0]["addr"]
                if mac:
                    return mac
        print(f"MAC address not found. will try again after sleep {interval}.")
        time.sleep(interval)

def delete_all_files(folder_path):
    
    if not os.path.exists(folder_path):
        print(f"[INFO] Folder '{folder_path}' does not exist.")
        return

    for file_name in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file_name)
        try:
            if os.path.isfile(file_path):
                os.remove(file_path)
                print(f"[INFO] Deleted: {file_path}")
        except Exception as e:
            print(f"[ERROR] Could not delete {file_path}: {e}")

def get_device_timezone():
    device_tz = get_localzone()
    timezone_name = device_tz.key
    return timezone_name

def mount_storage(payload):
    from utility_service import Globals
    
    # Check if already mounted
    mountpoint = payload["mountPoint"]
    is_mounted = subprocess.run(["mountpoint", "-q", mountpoint]).returncode == 0
    if is_mounted:
        return {"status": "OK", "msg": f"Already mounted at {mountpoint}"}

    """
    Mount a CIFS/SMB share dynamically based on MQTT payload.
    Expected payload:
    {
        "host": "192.168.1.12",
        "share": "test",
        "mountpoint": "/home/mandlacx/shared",
        "username": "WINDOWS_USER",
        "password": "WINDOWS_PASS",
        "uid": "mandlacx",
        "gid": "mandlacx",
        "dir_mode": "0777",
        "file_mode": "0666",
        "vers": "3.0"
    }
    """
    try:
        
        Globals.is_internal_storage = payload.get("isInternalStorage")
        Globals.last_mount_config = payload
        Globals.file_server_host = payload.get("hostIpAddress","")

        # 🔹 If using internal (Azure) storage → skip mounting
        if Globals.is_internal_storage:
            print("[mount_storage] Skipping CIFS mount because isInternalStorage=True")
            return {"status": "OK", "msg": "Internal (Azure) storage selected. Mount skipped."}
        
        share = payload["networkStorageLocation"]
        mountpoint = payload["mountPoint"]
        user = payload["userName"]
        passwd = payload["password"]

        uid = payload.get("uId", "mandlacx")
        gid = payload.get("gId", "mandlacx")
        dir_mode = payload.get("dir_mode", "0777")
        file_mode = payload.get("file_mode", "0666")
        vers = payload.get("vers", "3.0")

        # Ensure target directory exists
        os.makedirs(mountpoint, exist_ok=True)

        # check if already mounted
        with open("/proc/mounts") as f:
            if any(mountpoint in line for line in f):
                print(f"[mount_storage] Already mounted at {mountpoint}")
                return {"status": "OK", "msg": f"Already mounted at {mountpoint}"}
        
        # Write temp credentials file
        with tempfile.NamedTemporaryFile("w", delete=False) as cred_file:
            cred_file.write(f"username={user}\npassword={passwd}\n")
            cred_path = cred_file.name
        os.chmod(cred_path, 0o600)

        cmd = [
            "sudo", "mount", "-t", "cifs", f"{share}", mountpoint,
            "-o", f"credentials={cred_path},uid={uid},gid={gid},"
                  f"dir_mode={dir_mode},file_mode={file_mode},vers={vers}"
        ]
        print(f"[mount_storage] Running: {' '.join(cmd)}")
        
        result = subprocess.run(cmd, capture_output=True, text=True)

        os.remove(cred_path)  # cleanup

        if result.returncode == 0:
            print(f"[mount_storage] SUCCESS: Mounted {share} at {mountpoint}")
            Globals.last_mount_config = payload
            
            # Start HTTP server once mount is successful
            #start_http_server(mountpoint)
            
            return {"status": "OK", "msg": f"Mounted {share} at {mountpoint}"}
        else:
            print(f"[mount_storage] ERROR: {result.stderr.strip()}")
            return {"status": "FAILED", "msg": result.stderr.strip()}

    except Exception as e:
        return {"status": "FAILED", "msg": str(e)}
    
def unmount_storage(payload):
    from utility_service import Globals
    """
    Unmount a CIFS/SMB share dynamically.
    Expected payload:
    { "mountpoint": "/home/mandlacx/shared" }
    """
    try:
        mountpoint = payload["mountpoint"]
        is_mounted = subprocess.run(["mountpoint", "-q", mountpoint]).returncode == 0
        
        if is_mounted:
            cmd = ["sudo", "umount", mountpoint]
            print(f"[unmount_storage] Running: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True)

            if result.returncode == 0:
                print(f"[unmount_storage] SUCCESS: Unmounted {mountpoint}")
                Globals.last_mount_config = payload

                #Stop HTTP server after unmounting
                #stop_http_server()
                
                return {"status": "OK", "msg": f"Unmounted {mountpoint}"}
            else:
                print(f"[unmount_storage] ERROR: {result.stderr.strip()}")
                return {"status": "FAILED", "msg": result.stderr.strip()}
            
        else:
            print(f"[unmount_storage] INFO: {mountpoint} was not mounted, skipping unmount")
            return {"status": "OK", "msg": f"{mountpoint} was not mounted, skipping unmount"}

    except Exception as e:
        return {"status": "FAILED", "msg": str(e)}
