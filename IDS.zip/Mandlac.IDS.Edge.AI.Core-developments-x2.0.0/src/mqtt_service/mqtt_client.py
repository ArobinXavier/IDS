import os
import subprocess
import time
import paho.mqtt.client as mqtt
import json
from config_service import load_default_config, set_config, device_mode
from utility_service import Globals, restart_app, reboot, schedule_restart, mount_storage, unmount_storage #, screenshot
from camera_service import capture_image
from enums import Action, EdgeStatus
from log_service import view_log


# Default Configuration
config = load_default_config()
# MQTT Configuration
BROKER = config.get('mqtt_broker', '')
PORT = int(config.get('mqtt_broker_port', 1883))
USERNAME = config.get('mqtt_user_name', '')
PASSWORD = config.get('mqtt_password', '')
TOPIC_PREFIX = config.get('mqtt_topic_prefix', '')
TOPIC_DM_PREFIX = config.get('mqtt_dm_topic_prefix', '')
RECONNECT_SEC = config.get('mqtt_reconnect_seconds', '')
TOPIC_LWT = config.get('mqtt_topic_lwt', '')
TOPIC_ACK = config.get('mqtt_topic_ack', '')
CLIENT_ID_PREFIX = config.get('mqtt_client_id_prefix', 'ids')


# Dynamically construct the topic
MAC_ADDRESS = Globals.MAC_ADDRESS
TOPIC = f"{TOPIC_PREFIX}/{MAC_ADDRESS}"
TOPIC_DEVICE_MANAGER = f"{TOPIC_DM_PREFIX}/{MAC_ADDRESS}"

# Singleton instance of the MQTT client
client = None

def unknown_method(config):
    print(f"Unknown method. Config: {config}")

# Dictionary to map method to the corresponding handler function
method_dispatch = {
    "set_config": set_config,
    "restart_app": restart_app,
    "reboot": reboot,
    "capture_image": capture_image,
    "device_mode": device_mode,
    "mount_storage": mount_storage,
    "unmount_storage": unmount_storage,
    "view_log": view_log 
}

# Called when the client receives a CONNACK response from the broker
def on_connect(client, userdata, flags, rc):
    if rc == 0:  # Connection successful
        print(f"Connected with result code {rc}")
        # Subscribe to the topic every time the client connects
        client.subscribe(TOPIC)
        print(f"Subscribed to MQTT topic: {TOPIC}")
        online_message = json.dumps({"topic": TOPIC, "action": Action.STATUS_UPDATE, "payload": {"status": EdgeStatus.ONLINE, "mac": MAC_ADDRESS}})
        publish(TOPIC_ACK, online_message, 1, False)
    else:
        print(f"Failed to connect with result code {rc}")

def on_message(client, userdata, msg):
    print(f"on Message {msg}")
    try:
        raw_payload = msg.payload.decode()
        #print(f"Message received on topic {msg.topic}: {raw_payload}")
        message = json.loads(raw_payload)
    except Exception as e:
        print(f"[Error] Failed to decode JSON payload: {e}")
        return

    # Extract info
    method = message.get("action")
    request_payload = message.get("payload", {})

    # Handle dynamic mount/unmount actions
    if method == "mount_storage":
        Globals.last_mount_config = request_payload
        
        response_payload = mount_storage(request_payload)

        # 2️⃣ Save to DB only if mount succeeded
        if response_payload.get("status") == "OK":
            from config_service.config_manager import set_mount_storage_config
            db_response = set_mount_storage_config({"payload": request_payload})
            print(f"Mount storage DB save response: {db_response}")

    elif method == "unmount_storage":
        Globals.last_mount_config = request_payload
        response_payload = unmount_storage(request_payload)  # uses mountpoint from payload
        
    else:
    # Dispatch to other handlers
        handler = method_dispatch.get(method, unknown_method)
        response_payload = handler(request_payload)
    print(f"response payload::: {response_payload}")
    
    # Dispatch to handler
    handler = method_dispatch.get(method, unknown_method)
    response_payload = handler(request_payload)
    print(f"response payload::: {response_payload}")

    # Build ack message
    ack_message = {
        # "status": "OK",
        "correlation_id": message.get("correlation_id", '')
    }

    if isinstance(response_payload, dict):
        merged_payload = {**response_payload, **ack_message}
    else:
        merged_payload = ack_message

    message["payload"] = merged_payload

    try:
        response_json = json.dumps(message)
        print(f"Response Message::: {response_json}")
        publish(TOPIC_ACK, response_json, qos=1, retain=False)
        if method == 'set_config' or method == "mount_storage"or method == "unmount_storage":
            restart_me()
    except Exception as e:
        print(f"[Error] Failed to publish response: {e}")

# Call when messages needs to be published
def publish(topic, message, qos=1, retain=False):
    print(f"Publish::: {message}")
    global client
    if client is not None:
        client.publish(topic, message, qos, retain)
    else:
        print("MQTT client is not initialized. Cannot publish message.")

def start_mqtt_client():
    print(f"Dynamic Topic Name: {TOPIC}")
    global client
    if client is None:
        # Setup MQTT client
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION1, f'{CLIENT_ID_PREFIX}-{MAC_ADDRESS}')
        # Set username and password for MQTT connection
        client.username_pw_set(USERNAME, PASSWORD)
        
        # Set the Last Will and Testament (LWT) message
        LWT_MESSAGE = json.dumps({ "topic": TOPIC, "action": Action.STATUS_UPDATE, "payload": {"status": EdgeStatus.OFFLINE, "mac": MAC_ADDRESS}})
        client.will_set(TOPIC_ACK, payload=LWT_MESSAGE, qos=1, retain=False)

        # Assign event handlers
        client.on_connect = on_connect
        client.on_message = on_message
        # Connect to the MQTT broker
        # Retry logic for initial connection
        while True:
            try:
                print(f"Attempting to connect to MQTT broker at {BROKER}:{PORT}")
                client.connect(BROKER, PORT, keepalive=10)
                break  # Exit the loop if connection is successful
            except OSError as e:
                print(f"Connection failed: {e}. Retrying in {RECONNECT_SEC} seconds...")
                time.sleep(int(RECONNECT_SEC))

        # Start the MQTT loop to listen for incoming messages
        client.loop_forever()  # Use loop_forever to handle automatic reconnections

def get_current_topic():
    return TOPIC

def restart_me():
    print('Sending restart me request to MQTT, this restart will happen over Device manager.')
    request_json = json.dumps({
        "action": "control_service",
        "correlation_id": "",
        "topic": TOPIC_DEVICE_MANAGER,
        "payload": {
            "action": "restart",
            "service_name": "mandlacx-x.service"
        }
    })
    publish(TOPIC_DEVICE_MANAGER, request_json)