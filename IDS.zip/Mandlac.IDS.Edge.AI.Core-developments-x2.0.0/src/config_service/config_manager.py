import os
import sqlite3
import json
import subprocess
from utility_service import Globals

from utility_service import SQL_LITE_FILE_PATH 

# Default Configuration
DEFAULT_CONFIG_FILE = os.path.join(os.path.dirname(__file__), 'config.json')
# Ensure the directory exists
os.makedirs(os.path.dirname(SQL_LITE_FILE_PATH), exist_ok=True)

# Initialize the database and table
def create_table():
    print('Installation::Create config table if not exists!')
    conn = sqlite3.connect(SQL_LITE_FILE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    ''')
    conn.commit()
    conn.close()

# Update multiple rows
#configs_to_update = {
    #'server': 'mqtt.newserver.com',
    #'port': '1884',
    #'username': 'newuser',
    #'password': 'newpassword'
#}
def set_config(configs):
    print(f"set_config::: {configs}")
    conn = sqlite3.connect(SQL_LITE_FILE_PATH)
    cursor = conn.cursor()

    print(f"set_config configuration:::: {configs}")
    camera_id = configs.get("cameraId")
    status_id = configs.get("statusId")
    configuration = configs.get("configuration")

    if configuration is not None and status_id is not None:
        configuration["statusId"] = status_id

    print (f"set_config Camera {camera_id}")
    print (f"set_config configuration {configuration}")
    print (f"set_config Status {status_id}")

    if camera_id is not None and configuration is not None:
        value_str = json.dumps(configuration)  # Convert the dict to JSON string
        key_str = str(camera_id)  # Ensure key is string if needed
        print(f"Inserting: key={key_str}, value={value_str}")
        cursor.execute('''
            INSERT OR REPLACE INTO config (key, value)
            VALUES (?, ?)
        ''', (key_str, value_str))
        print(f"test ::::: {value_str}")
    else:
        print("Missing cameraId or configuration in configs.")
    
    # Globals.prepare_service_config(-1, camera_id, value_str)

    conn.commit()
    conn.close()
    from utility_service import get_device_timezone
    device_timezone = get_device_timezone()
    return {'status': 'OK', "timezone": device_timezone}

def set_mount_storage_config(configs):
    """
    Handles 'mount_storage' action — stores payload in the existing config table.
    Uses 'mountId' as the key and the entire payload as the value (JSON string).
    """
    print(f"set_mount_storage_config::: {configs}")

    # Extract payload
    payload = configs.get("payload", {})
    mount_id = payload.get("mountId")

    if mount_id is None:
        print("❌ mountId not found in payload. Skipping save.")
        return {'status': 'FAILED', 'reason': 'Missing mountId in payload'}

    # Connect to existing SQLite database
    conn = sqlite3.connect(SQL_LITE_FILE_PATH)
    cursor = conn.cursor()

    try:
        key_str = str(mount_id)
        value_str = json.dumps(payload)

        print(f"🗄️ Inserting/Updating mount storage config: key={key_str}")
        cursor.execute('''
            INSERT OR REPLACE INTO config (key, value)
            VALUES (?, ?)
        ''', (key_str, value_str))

        conn.commit()
        print(f"Successfully saved mount storage config for mountId={mount_id}")
        from utility_service import get_device_timezone
        device_timezone = get_device_timezone()
        return {'status': 'OK', "timezone": device_timezone}

    except Exception as e:
        print(f"Error while saving mount storage config: {e}")
        return {'status': 'FAILED', 'reason': str(e)}

    finally:
        if conn:
            conn.close()


def update_config(config):
    print(f"update_config::: {config}")
    # Expecting a single key-value pair in config
    if not config or len(config) != 1:
        return {'status': 'FAILED', 'reason': 'Invalid config format'}
    conn = sqlite3.connect(SQL_LITE_FILE_PATH)
    cursor = conn.cursor()

    key_str, value = next(iter(config.items()))
    value_str = json.dumps(value) if isinstance(value, (dict, list)) else str(value)

    try:
        cursor.execute('''
            INSERT OR REPLACE INTO config (key, value)
            VALUES (?, ?)
        ''', (key_str, value_str))

        conn.commit()
        return {'status': 'OK'}
    except Exception as e:
        return {'status': 'FAILED', 'reason': str(e)}
    finally:
        if (conn):
            conn.close()

# Get a config value
def get_config(key, default=None):
    conn = sqlite3.connect(SQL_LITE_FILE_PATH)
    cursor = conn.cursor()
    cursor.execute('SELECT value FROM config WHERE key = ?', (key,))
    result = cursor.fetchone()
    conn.close()
    return json.loads(result[0]) if result else default

# Get all config values
def get_all_config(default=None):
    conn = sqlite3.connect(SQL_LITE_FILE_PATH)
    cursor = conn.cursor()
    
    try:
        cursor.execute('SELECT key, value FROM config WHERE key > 0')
        rows = cursor.fetchall()
        return {key: value for key, value in rows} if rows else default
    finally:
        conn.close()


def load_default_config():
    try:
        with open(DEFAULT_CONFIG_FILE, 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"Default configuration file not found: {SQL_LITE_FILE_PATH}")
        return {}
    except json.JSONDecodeError:
        print(f"Failed to parse default configuration file: {SQL_LITE_FILE_PATH}")
        return {}
    
def device_mode(request):
    mode = request['mode']
    camera_key = request['cameraId']
    Globals.cam_mode_map[str(request['cameraId'])] = mode
    configuration = get_config(camera_key)
    if configuration is not None and mode is not None:
        configuration["statusId"] = mode
        payload = {str(camera_key): configuration}  # Ensure key is string
        update_config(payload)

# Initialize the table (if it doesn't exist)
create_table()

# config_service/settings.py

# Hardcoded mapping of RTSP URL → deviceInstanceId
CAMERA_MAP = {
    "rtsp://admin:Triton123@192.168.1.111/Streaming/Channels/101": "device_101",
    "rtsp://admin:Triton123@192.168.1.113/Streaming/Channels/101": "device_113"
}

# Extracted for use in pipeline
RTSP_URLS = list(CAMERA_MAP.keys())

# Model + postprocess
HEF_PATH = "/home/pi/venv_changed/Mandlac.IDS.Edge.AI.Core/models/yolov11n_h8l.hef"
POSTPROCESS_SO = "/home/pi/venv_changed/Mandlac.IDS.Edge.AI.Core/libyolo_hailortpp_post.so"
