from pymodbus.client import ModbusTcpClient
import time
from enums.relay_actions import RelayAction
from utility_service import Globals
import threading

# Structure:
# Globals.relay_queue.put((ip, port, RelayAction.ON))

clients = {}         # { (ip, port): ModbusTcpClient }
relay_states = {}    # { (ip, port): bool }

def get_client(ip, port):
    """Get or create a ModbusTcpClient for a given (IP, PORT)."""
    key = (ip, port)
    client = clients.get(key)

    # If client exists but disconnected, reconnect
    if client and not client.connected:
        try:
            client.connect()
            print(f"[INFO] Reconnected Modbus client {ip}:{port}")
        except Exception as e:
            print(f"[ERROR] Failed to reconnect {ip}:{port} -> {e}")
            return None

    # If client doesn’t exist, create new one
    if not client:
        try:
            client = ModbusTcpClient(ip, port=port)
            if client.connect():
                clients[key] = client
                print(f"[INFO] Connected new Modbus client {ip}:{port}")
            else:
                print(f"[ERROR] Could not connect to Modbus device {ip}:{port}")
                return None
        except Exception as e:
            print(f"[ERROR] Connection failed for {ip}:{port} -> {e}")
            return None

    return client


def relay_worker():
    """Relay worker that manages multiple Modbus devices."""
    print("[INFO] Relay worker started for multi-device management")

    try:
        while True:
            # Expected queue item: (ip, port, command)
            cmd_tuple = Globals.relay_queue.get()  # Blocking

            if not isinstance(cmd_tuple, tuple) or len(cmd_tuple) < 3:
                print(f"[WARN] Invalid relay command format: {cmd_tuple}")
                continue

            ip, port, cmd = cmd_tuple
            client = get_client(ip, port)
            if not client:
                continue  # Skip if client connection failed

            key = (ip, port)
            current_state = relay_states.get(key)

            new_state = None
            if cmd == RelayAction.ON:
                new_state = True
            elif cmd == RelayAction.OFF:
                new_state = False
            else:
                print(f"[WARN] Unknown relay command: {cmd}")
                continue

            # Change only if state differs
            if new_state != current_state:
                try:
                    client.write_coil(0, new_state)
                    relay_states[key] = new_state
                    print(f"[INFO] Relay {'ON' if new_state else 'OFF'} for {ip}:{port}")
                except Exception as e:
                    print(f"[ERROR] Failed to write coil {ip}:{port} -> {e}")
            else:
                print(f"[DEBUG] Ignored duplicate relay command for {ip}:{port}")

            time.sleep(0.2)
    except Exception as e:
        print(f"[ERROR] Relay worker crashed: {e}")