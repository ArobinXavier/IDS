import serial
import threading
import time 
from enums import SirenAction
from utility_service import Globals

PORT = "/dev/ttyACM0"  
BAUD = 115200         

def send(cmd: str):
    try:
        with serial.Serial(PORT, BAUD, timeout=1) as ser:
            ser.write((cmd.strip() + "\n").encode())
            reply = ser.readline().decode().strip()
            print("<<", reply)
    except serial.SerialException as e:
        print(f"Serial Error: {e}")
    except Exception as e:
        print(f"Error: {e}")
    
def siren_worker():
    while True:
        cmd = Globals.siren_queue.get()
        
        if cmd == SirenAction.ON:
            try:
                print("[INFO] Siren ON command received")
                send(cmd.value)
            except Exception as e:
                print(f"[ERROR] Failed to turn ON siren: {e}")
                
        elif cmd == SirenAction.OFF:
            try:
                print("[INFO] Siren OFF command received")
                send(cmd.value)
            except Exception as e:
                print(f"[ERROR] Failed to turn OFF siren: {e}")
                
        else:
            print(f"[WARN] Unknown siren command: {cmd}")
            
        time.sleep(0.5)          