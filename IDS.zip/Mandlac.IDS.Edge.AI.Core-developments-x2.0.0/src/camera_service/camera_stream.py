import cv2
import json
import os
import uuid
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed, TimeoutError
from azure.storage.blob import BlobServiceClient, ContentSettings
from config_service import get_config, load_default_config, get_all_config
from enums import EdgeStatus
from utility_service import get_device_timezone, VAR_DATA_DIR, VAR_MODEL_DIR, VAR_CAPTURE_IMAGE_DIR

# Default Configuration
config = load_default_config() 
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_FILEPATH = os.path.join(VAR_MODEL_DIR, config.get("model_hef_file_name", ''))
# POSTPROCESS_SO = os.path.join(VAR_DATA_DIR, config.get("gst_postprocess_so", ''))
POSTPROCESS_SO = os.path.join(BASE_DIR, config.get("model_location", ''), config.get("gst_postprocess_so", ''))
print(f'MODEL_FILEPATH: {MODEL_FILEPATH}, Is Exists: {os.path.isfile(MODEL_FILEPATH)}')
print(f'POSTPROCESS_SO: {POSTPROCESS_SO}, Is Exists: {os.path.isfile(POSTPROCESS_SO)}')
DIRECTORY_NAME_CAMERA_CAPTURE = config.get('directory_name_camera_capture', '')
CAMERA_STREAM_URL_PATTERN = config.get('camera_stream_url', '')

AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
CONTAINER_NAME = config.get('azure_container_name', '')

def capture_image(request):
    try:
        print(f"Capture Image method called ::: {request}")
         # Directory where the image will be saved
        print("Capture Image method called")

        (frame, file_name) = get_camera_frame(request)
        
        success, encoded_image = cv2.imencode('.webp', frame, [int(cv2.IMWRITE_WEBP_QUALITY), 80])
        if not success:
            raise Exception("Failed to encode frame as WebP.")
        
        image_bytes = encoded_image.tobytes()
        
        uid = str(uuid.uuid4())
        blob_path = f"{uid}/{file_name}"
        
        blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_path)

        blob_client.upload_blob(image_bytes, overwrite=True, content_settings=ContentSettings(content_type='image/webp'))
        
        blob_url = blob_client.url
        
        timezone = get_device_timezone()
        
        return {'status': 'OK', "file_url": blob_url, "timezone": timezone}
    except Exception as e:
        return {'status': 'NOK', 'message': str(e)}
    
def get_camera_frame(config):
    rtsp_url = config.get('rtsp_url', '')
    print(f"Trying camera: {rtsp_url}")
    
    cap = cv2.VideoCapture(rtsp_url)
    if not cap.isOpened():
        print(f"❌ Failed to connect to camera {rtsp_url}")
        raise ConnectionError(f"❌ Failed to connect to camera {rtsp_url}")

    ret, frame = cap.read()
    cap.release()

    if not ret:
        print(f"⚠️ Failed to read frame from camera {rtsp_url}")
        raise Exception(f"⚠️ Failed to read frame from camera {rtsp_url}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f'camera_{timestamp}_captured_image.jpg'
    return (frame, file_name)

def get_all_camera_streams():
    camera_configs = get_all_config()  # Returns dict like {"cam1": "{}", "cam2": "{}"}
    rtsp_streams = {}
    if camera_configs:
        for cam_key, cam_config_str in camera_configs.items():
            try:
                print(f"get_all_camera_streams {cam_config_str}")
                # Parse JSON string into a dict
                if isinstance(cam_config_str, str):
                    cam_config = json.loads(cam_config_str)
                else:
                    cam_config = cam_config_str  # Already a dict (if applicable)
                    
                rtsp_url = cam_config.get('rtsp_url', '')
                rtsp_streams[cam_key] = {
                    "rtspurl": rtsp_url,
                    "configuration": cam_config
                }
            except (KeyError, json.JSONDecodeError, TypeError) as e:
                print(f"Error processing {cam_key}: {e}")

    return rtsp_streams
    
def validate_camera_sources(camera_sources):
    if not camera_sources:
        print("[ERROR] No camera sources provided.")
        return False

    for cam_id, data in camera_sources.items():
        if not isinstance(data, dict) or "rtspurl" not in data or "configuration" not in data:
            print(f"[ERROR] Invalid camera config for '{cam_id}': {data}")
            return False

    return True
    
def build_pipeline_string():
    rtsp_sources = ""
    streamrouter_input_streams = ""
    sink = ""
    cam_keys = []
    cam_payload = {}
    
    print("[INFO] Fetching camera configuration...")
    camera_sources = get_all_camera_streams()

    if not validate_camera_sources(camera_sources):
        return

    if not camera_sources:
        raise ValueError("No camera sources provided.")

    for i, (cam_key, cam_data) in enumerate(camera_sources.items()):
        try:
            rtsp_url = cam_data["rtspurl"]
            payload = cam_data["configuration"]
            cam_payload[cam_key] = payload
        except KeyError as e:
            print(f"Missing key in camera data for '{cam_key}': {e}")
            raise

        cam_keys.append(cam_key)
        print(f"RTSP source for '{cam_key}': {rtsp_url}")

        rtsp_sources += f"""
        rtspsrc location={rtsp_url} name=source_{cam_key} message-forward=true ! rtph264depay !
        queue name=hailo_preprocess_q_{cam_key} leaky=no max-size-buffers=5 !
        decodebin ! queue leaky=downstream max-size-buffers=5 ! videoscale n-threads=8 !
        video/x-raw,pixel-aspect-ratio=1/1 ! videoconvert n-threads=4 ! video/x-raw,pixel-aspect-ratio=1/1 !
        identity name=identity_{cam_key} signal-handoffs=true !
        fun.sink_{cam_key} sid.src_{cam_key} !
        queue name=comp_q_{cam_key} leaky=downstream max-size-buffers=5 !
        comp.sink_{cam_key}
        """

        xpos = 640 * i
        ypos = 0
        sink += f"sink_{cam_key}::xpos={xpos} sink_{cam_key}::ypos={ypos} "
        streamrouter_input_streams += f"src_{cam_key}::input-streams=\"<sink_{cam_key}>\" "

    pipeline_str = f"""
    hailoroundrobin mode=0 name=fun !
    queue name=hailo_pre_infer_q_0 leaky=downstream max-size-buffers=5 !
    hailonet hef-path={MODEL_FILEPATH} nms-score-threshold=0.3 nms-iou-threshold=0.45 output-format-type=HAILO_FORMAT_TYPE_FLOAT32 !
    queue name=hailo_postprocess0 leaky=no max-size-buffers=30 !
    hailofilter so-path={POSTPROCESS_SO} qos=false name=hailofilter0 !
    queue name=hailo_draw0 leaky=no max-size-buffers=30 !
    hailooverlay ! hailostreamrouter name=sid {streamrouter_input_streams}
    compositor name=comp start-time-selection=0 {sink}!
    videoscale n-threads=4 !
    video/x-raw,width=1920,height=640 !
    fakesink sync=false

    {rtsp_sources}
    """

    print("Generated GStreamer pipeline string successfully.")
    return pipeline_str, cam_keys, cam_payload
