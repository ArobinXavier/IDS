from enum import Enum

class EdgeStatus(str, Enum):
    ONLINE = "ONLINE"
    OFFLINE = "OFFLINE"