from enum import Enum

class RelayAction(str, Enum):
    ON = "True"
    OFF = "False"
