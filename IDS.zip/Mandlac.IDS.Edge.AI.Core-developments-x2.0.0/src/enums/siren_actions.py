from enum import Enum

class SirenAction(str, Enum):
    ON = "on"
    OFF = "off"
