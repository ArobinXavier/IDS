from enum import Enum

class Action(str, Enum):
    SET_CONFIG = "set_config"
    GET_CONFIG = "get_config"
    STATUS_UPDATE = "status_update"
    CAPTURE_IMAGE = "capture_image"
    INTRUSION_DETECTED = "intrusion_detected"
