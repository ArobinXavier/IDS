import cv2
import time
import json
import tempfile
import os
from datetime import datetime
from utility_service import Globals
from mqtt_service import publish
from config_service import load_default_config
from azure.storage.blob import BlobServiceClient, ContentSettings
import imageio

# Mounted Windows share path
# SHARED_DIR = "/home/mandlacx/intranet"
config = load_default_config()
AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
CONTAINER_NAME = config.get('azure_container_name', '')
# MQTT topic for events
reply_topic = config.get('mqtt_topic_events', '')

def video_upload_worker():
    time.sleep(1)
    print('video_upload_worker started!')
    while True:
        try:
            while not Globals.full_event_upload_queue.empty():
                event = Globals.full_event_upload_queue.get()
                handle_event_trigger(event)

            time.sleep(0.005)
        except Exception as e:
            print(f"[WARN] video_upload_worker exception: {e}")
            time.sleep(1)  # Retry delay

def handle_event_trigger(event: dict):
    from utility_service import Globals
    
    try:
        frames = event['payload'].get('frames')
        if not frames:
            print("[WARN] No frames in event payload")
            return
        urls=[]
        if Globals.is_internal_storage:
            urls = upload_to_azure(event, frames)
        else:
            # Local storage upload
            urls = upload_to_local(event, frames)
        
        event['payload']['file_urls'] = urls
        del event['payload']['frames']

        publish(reply_topic, json.dumps(event), qos=1, retain=False)

    except Exception as e:
        print(f"[ERROR] handle_event failed: {e}")

def compress_frames_to_video_bytes(frames, fps=28, resize_to=(320, 240)):
    with tempfile.NamedTemporaryFile(suffix=".mp4", delete=True) as tmp:
        writer = imageio.get_writer(
            tmp.name,
            format='FFMPEG',
            mode='I',
            fps=fps,
            codec='libx264',
            bitrate='400k',
            macro_block_size=None
        )

        for frame in frames:
            resized = cv2.resize(frame, resize_to, interpolation=cv2.INTER_NEAREST)
            rgb = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
            writer.append_data(rgb)

        writer.close()
        tmp.seek(0)
        video_bytes = tmp.read()
        return video_bytes

def upload_to_azure(event, frames):
    """Upload video to Azure Blob Storage"""
    try:
        euid = event['payload'].get('eUID', 'unknown')
        video_bytes = compress_frames_to_video_bytes(frames)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"{euid}_{timestamp}.mp4"
        blob_path = f"{euid}/{file_name}"

        blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_path)
        blob_client.upload_blob(video_bytes, overwrite=True, content_settings=ContentSettings(content_type='video/mp4'))

        print(f"✅ Uploaded to Azure Blob: {blob_client.url}")
        return [blob_client.url]
    except Exception as e:
        print(f" Azure upload failed: {e}")
        return []
    
def upload_to_local(event, frames):
    """Save video to local SMB or mounted storage"""
    try:
        euid = event['payload'].get('eUID', 'unknown')
        video_bytes = compress_frames_to_video_bytes(frames)

        mount_cfg = Globals.last_mount_config
        if not mount_cfg:
            raise Exception("No mount configuration found (Globals.last_mount_config is None).")

        mountpoint = mount_cfg["mountPoint"]
        host = Globals.file_server_host #Mandlacx ip address
        
        # Create folder dynamically
        euid_dir = os.path.join(mountpoint, euid)
        os.makedirs(euid_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_name = f"{euid}_{timestamp}.mp4"
        output_path = os.path.join(euid_dir, file_name)

        with open(output_path, "wb") as f:
            f.write(video_bytes)

        # UNC path for Windows clients
        port = 8082
        unc_path = f"http://{host}:{port}/{euid}/{file_name}"
        print(f"✅ Saved video locally: {output_path}")
        print(f"   (Accessible as: {unc_path})")
        return [unc_path]
    except Exception as e:
        print(f"❌ Local upload failed: {e}")
        return []