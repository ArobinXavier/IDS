import cv2
import time
import json
import os
from datetime import datetime
from utility_service import Globals
from mqtt_service import publish
from config_service import load_default_config
from azure.storage.blob import BlobServiceClient, ContentSettings
 
# Mounted Windows share path
# SHARED_DIR = "/home/mandlacx/intranet"
config = load_default_config() 
reply_topic = config.get('mqtt_topic_events', '')
AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
CONTAINER_NAME = config.get('azure_container_name', '')

# MQTT topic for events
reply_topic = config.get('mqtt_topic_events', '')
 
def fast_upload_worker():
    time.sleep(1)
    print('fast_upload_worker started!')
    while True:
        try:
            while not Globals.fast_upload_queue.empty():
                event = Globals.fast_upload_queue.get()
                handle_event_trigger(event)
            time.sleep(0.005)
        except Exception as e:
            print(f"[WARN] fast_upload_worker exception: {e}")
            time.sleep(1)  # Retry delay
 
def handle_event_trigger(event: dict):
    from utility_service import Globals
    
    frame = event['payload'].get('frame')
    if frame is None:
        print("[WARN] No frame in event payload")
        return

    if Globals.is_internal_storage:
        urls = fast_upload_to_azure(event, frame)
    else:
        urls = fast_upload_to_local(event, frame)

    event['payload']['file_urls'] = urls
    del event['payload']['frame']
    publish(reply_topic, json.dumps(event), qos=1, retain=False)
    
def fast_upload_to_local(event: dict, frame):
    try:
        # Resize and encode frame
        resized_frame = cv2.resize(frame, (320, 240), interpolation=cv2.INTER_AREA)
        euid = event['payload'].get('eUID', 'unknown')
        success, encoded_image = cv2.imencode('.webp', resized_frame, [int(cv2.IMWRITE_WEBP_QUALITY), 80])
        if not success:
            raise Exception("Failed to encode frame as WebP.")
        image_bytes = encoded_image.tobytes()
        
        mount_cfg = Globals.last_mount_config
        if not mount_cfg:
            raise Exception("No mount configuration found (Globals.last_mount_config is None).")
        
        host = Globals.file_server_host #Mandlacx ip address
        mountpoint = mount_cfg["mountPoint"]
        
        # Create EUID folder dynamically inside mountpoint
        euid_dir = os.path.join(mountpoint, euid)
        os.makedirs(euid_dir, exist_ok=True)
 
        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        webp_file_name = f"{euid}_{timestamp}.webp"
        output_path = os.path.join(euid_dir, webp_file_name)
        
        # Write to SMB share
        with open(output_path, "wb") as f:
            f.write(image_bytes)
            
        # UNC path for Windows clients
        port = 8082
        unc_path = f"http://{host}:{port}/{euid}/{webp_file_name}"
        print(f"✅ Saved snapshot to Windows share: {output_path}")
        print(f"   (Accessible on laptop as: {unc_path})")
        return [unc_path]
 
    except Exception as e:
        print(f"❌ Error saving frame to Windows share: {e}")
        return []
    
def fast_upload_to_azure(event: dict, frame):
    try:
        # Resize and encode frame
        resized_frame = cv2.resize(frame, (320, 240), interpolation=cv2.INTER_AREA)
        euid = event['payload'].get('eUID', 'unknown')
        success, encoded_image = cv2.imencode('.webp', resized_frame, [int(cv2.IMWRITE_WEBP_QUALITY), 80])
        if not success:
            raise Exception("Failed to encode frame as WebP.")
        image_bytes = encoded_image.tobytes()

        # Generate blob path
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        webp_file_name = f"{euid}_{timestamp}.webp"
        blob_path = f"{euid}/{webp_file_name}"

        blob_service_client = BlobServiceClient.from_connection_string(AZURE_CONNECTION_STRING)
        blob_client = blob_service_client.get_blob_client(container=CONTAINER_NAME, blob=blob_path)
        blob_client.upload_blob(image_bytes, overwrite=True, content_settings=ContentSettings(content_type='image/webp'))
        
        print(f"✅ Uploaded to Azure Blob: {blob_client.url}")
        return [blob_client.url]

    except Exception as e:
        print(f"❌ Error uploading frame to Azure: {e}")
        return []