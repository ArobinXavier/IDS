import os
import requests

from utility_service import VAR_MODEL_DIR
from config_service import load_default_config

# Default Configuration
config = load_default_config()
BASE_MODEL_URL = config.get("base_model_url", '')
MODEL_FILEPATH = os.path.join(VAR_MODEL_DIR, config.get("model_hef_file_name", ''))
print(MODEL_FILEPATH)
def download_model_from_api():
    try:
        if os.path.exists(MODEL_FILEPATH):
            print(f"[INFO] Model already exists at {MODEL_FILEPATH}, skipping download.")
            return
        
        print(f"[INFO] Downloading model from {BASE_MODEL_URL}...")

        response = requests.get(BASE_MODEL_URL, stream=True)
        response.raise_for_status()

        # Ensure the directory exists
        os.makedirs(os.path.dirname(MODEL_FILEPATH), exist_ok=True)

        # Download and overwrite existing file
        with open(MODEL_FILEPATH, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        print(f"[INFO] Model downloaded and saved to {MODEL_FILEPATH}")

    except Exception as e:
        print(f"[ERROR] Failed to download model: {e}")
    