import importlib.util
import os
 
def load_hailo():
    # Try to locate the Hailo native module manually
    possible_paths = [
        "/usr/lib/python3/dist-packages/hailo.cpython-311-aarch64-linux-gnu.so",
        "/usr/local/lib/python3.11/dist-packages/hailo.cpython-311-aarch64-linux-gnu.so"
    ]
 
    for path in possible_paths:
        if os.path.exists(path):
            spec = importlib.util.spec_from_file_location("hailo", path)
            hailo = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(hailo)
            return hailo
 
    raise ImportError("[ERROR] Could not locate 'hailo' native module")

def load_gst_modules():
    import importlib
    gi = importlib.import_module("gi")
    gi.require_version('Gst', '1.0')
    gi.require_version('GObject', '2.0')
    Gst = importlib.import_module('gi.repository.Gst')
    GObject = importlib.import_module('gi.repository.GObject')
    return Gst, GObject
