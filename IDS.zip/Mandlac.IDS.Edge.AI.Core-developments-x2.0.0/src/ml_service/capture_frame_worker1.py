import cv2
import time
from utility_service import Globals
from mqtt_service import restart_me

def capture_frame_worker1():
    time.sleep(1)
    print(f'capture_frame_worker1 started! Recording time: {Globals.POST_EVENT_SECONDS}')
    
    cam_idx = 1
    deviceId = next((k for k, v in Globals.cam_key_idx_map.items() if v == cam_idx), None)
    rtsp_url = Globals.device_config_map1[deviceId]
    
    if not rtsp_url:
        print('capture_frame_worker1 will be dead thread because rtsp_url not supplied!')
        return
    
    cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
    cap.set(cv2.CAP_PROP_FPS, 10)
    
    reconnected = False
    
    while True:
        try:
            if not cap.isOpened():
                print("capture_frame_worker1 Stream timeout. Reconnecting...")
                cap.release()
                cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_FPS, 10)
                time.sleep(1)
                reconnected = True
                continue
            
            ret, frame = cap.read()
            if not ret:
                print("capture_frame_worker1 Stream timeout. Reconnecting...")
                cap.release()
                cap = cv2.VideoCapture(rtsp_url, cv2.CAP_FFMPEG)
                cap.set(cv2.CAP_PROP_FPS, 10)
                time.sleep(1)
                reconnected = True
                continue
            
            # ✅ Trigger event *once* after successful reconnection
            if reconnected:
                print("capture_frame_worker1, camera streams reconnected sending single to MQTT for reconnection!")
                restart_me()
                reconnected = False

            Globals.frame_hold_queue1.append(frame)
            now = time.time()
            Globals.pre_event_frames1.append((now, frame))
            trim_threshold = now - Globals.PREV_HOLD_SECONDS
            while Globals.pre_event_frames1 and Globals.pre_event_frames1[0][0] < trim_threshold:
                Globals.pre_event_frames1.popleft()
            
            for euid, info in list(Globals.ongoing_post_events1.items()):
                elapsed = time.time() - info["payload"]["start_time"]
                if elapsed <= Globals.POST_EVENT_SECONDS:
                    # Still within 5 seconds → keep adding frames
                    info["payload"].setdefault("frames", []).append(frame)
                else:
                    # 5 seconds passed → push full event and remove it
                    Globals.full_event_upload_queue.put(info)

                    # Remove from ongoing events
                    del Globals.ongoing_post_events1[euid]
                    
            time.sleep(.005)
        except Exception as e:
            print(f"[WARN] capture_frame_worker1_not_invoked: {e}")
            time.sleep(1)  # Retry delay
