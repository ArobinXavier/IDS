import json
import os
from datetime import datetime

from config_service import load_default_config
from config_service.config_manager import RTSP_URLS, CAMERA_MAP
from camera_service import build_pipeline_string
from utility_service import Globals
import sys
print("[DEBUG] Python version:", sys.version)
print("[DEBUG] Python executable:", sys.executable)
import sys, site
site.addsitedir('/usr/lib/python3/dist-packages')
sys.path.append('/usr/lib/python3/dist-packages')
import gi
gi.require_version('Gst', '1.0')
gi.require_version('GObject', '2.0')
from gi.repository import Gst, GObject

from .hailo_util import load_hailo
hailo = load_hailo()
print(hailo)

# Global buffer map
buffer_camera_map = {}

def on_identity_handoff(identity, buffer, cam_key):
    pts = buffer.pts
    buffer_camera_map[pts] = cam_key
    return Gst.FlowReturn.OK

def on_hailofilter_buffer_probe(pad, info):
    buffer = info.get_buffer()
    if buffer:
        try:
            pts = buffer.pts
            cam_key = buffer_camera_map.get(pts)
            idx = Globals.cam_key_idx_map[cam_key]
            queue = getattr(Globals, f"detection_queue{idx}")
            all_labels_set = getattr(Globals, f"all_labels_set{idx}")
            del buffer_camera_map[pts]
            roi_list = hailo.get_roi_from_buffer(buffer)
            detections = roi_list.get_objects_typed(hailo.HAILO_DETECTION)
            
            # Initialize with default values
            detection_summary = {
                label: 0.0 for label in all_labels_set
            }
            detection_summary.update({
                f"{label}_count": 0 for label in all_labels_set
            })
            detection_summary.update({
                f"{label}_bbox": {} for label in all_labels_set
            })
            for det in detections:
                label = det.get_label().lower()
                if label not in all_labels_set:
                    continue
                conf = det.get_confidence()
                bbox = det.get_bbox()
                scale = 640
                s_bbox = {
                    "xmin": bbox.xmin() * scale,
                    "ymin": bbox.ymin() * scale,
                    "xmax": bbox.xmax() * scale,
                    "ymax": bbox.ymax() * scale
                }
                
                if label not in detection_summary:
                    detection_summary[label] = conf
                    detection_summary[f"{label}_count"] = 1
                    detection_summary[f"{label}_bbox"] = s_bbox
                else:
                    if conf > detection_summary[label]:
                        detection_summary[label] = conf
                        detection_summary[f"{label}_bbox"] = s_bbox
                    detection_summary[f"{label}_count"] += 1
                
            if detection_summary:
                queue.append({'pts': pts, 'detections': detection_summary})
                
        except Exception as e:
            print(f"⚠️ Error parsing detection: {e}")

    return Gst.PadProbeReturn.OK

def launch_pipeline(pipeline_str, cam_keys):
    print("Initializing GStreamer...")
    Gst.init(None)
    try:
        pipeline = Gst.parse_launch(pipeline_str)
        print("Pipeline parsed and launched.")
    except Exception as e:
        print(f"Failed to parse pipeline: {e}")
        return

    for cam_key in cam_keys:
        identity = pipeline.get_by_name(f"identity_{cam_key}")
        if identity:
            try:
                identity.connect("handoff", on_identity_handoff, cam_key)
                print(f"Connected handoff for identity_{cam_key}")
            except Exception as e:
                print(f"Failed to connect handoff for identity_{cam_key}: {e}")
        else:
            print(f"identity_{cam_key} not found in pipeline.")

    hailofilter = pipeline.get_by_name("hailofilter0")
    if hailofilter:
        pad = hailofilter.get_static_pad("src")
        if pad:
            try:
                pad.add_probe(Gst.PadProbeType.BUFFER, on_hailofilter_buffer_probe)
                print("Buffer probe added to hailofilter0.")
            except Exception as e:
                print(f"Failed to add buffer probe: {e}")
        else:
            print("Could not get src pad of hailofilter0.")
    else:
        print("hailofilter0 element not found.")

    loop = GObject.MainLoop()
    try:
        pipeline.set_state(Gst.State.PLAYING)
        print("Pipeline set to PLAYING.")
        loop.run()
    except KeyboardInterrupt:
        print("Keyboard interrupt received. Stopping pipeline...")
    except Exception as e:
        print(f"Pipeline runtime error: {e}")
    finally:
        pipeline.set_state(Gst.State.NULL)
        print("Pipeline stopped and cleaned up.")
