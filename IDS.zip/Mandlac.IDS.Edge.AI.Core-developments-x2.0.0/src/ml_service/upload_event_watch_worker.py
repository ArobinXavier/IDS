import time
from utility_service import Globals
from config_service import load_default_config
from mqtt_service import get_current_topic

config = load_default_config()
AZURE_CONNECTION_STRING = config.get('azure_blob_connection_string', '')
CONTAINER_NAME = config.get('azure_container_name', '')
current_topic = get_current_topic()
        
def upload_event_watch_worker():
    time.sleep(1)
    print('upload event watch worker started!')
    while True:
        try:
            while not Globals.capture_frame_queue0.empty():
                event = Globals.capture_frame_queue0.get()
                capture_and_send_upload_signal0(event)
                
            while not Globals.capture_frame_queue1.empty():
                event = Globals.capture_frame_queue1.get()
                capture_and_send_upload_signal1(event)
                
            while not Globals.capture_frame_queue2.empty():
                event = Globals.capture_frame_queue2.get()
                capture_and_send_upload_signal2(event)
                
            time.sleep(.005)
        except Exception as e:
            print(f"[WARN] capture_frame0_not_invoked: {e}")
            time.sleep(1)  # Retry delay

def capture_and_send_upload_signal0(event: dict):
    euid = event.get('euid')
    cam_key = event.get('cam_key')
    if Globals.frame_hold_queue0:                    
        # Capture current frame and send put it to fast upload queue
        frame = Globals.frame_hold_queue0[-1]
                
        event_message = {
            "topic": current_topic,
            "module": "IDS",
            "action": "intrusion_shots",
            "target": "MQTT",
            "payload": {
                "eUID": euid,
                "frame": frame,
                "deviceInstanceId": cam_key,
                "file_urls": []
                }
            }
        
        Globals.fast_upload_queue.put(event_message)
        print(f'Globals.fast_upload_queue: {Globals.fast_upload_queue.qsize()}')
        
    if euid not in Globals.ongoing_post_events0:
        event_message = {
            "topic": current_topic,
            "module": "IDS",
            "action": "intrusion_shots",
            "target": "MQTT",
            "payload": {
                "eUID": euid,
                "deviceInstanceId": cam_key,
                "start_time": time.time(),
                "frames": [frame for _, frame in Globals.pre_event_frames0]
                }
            }
        Globals.ongoing_post_events0[euid] = event_message
        
def capture_and_send_upload_signal1(event: dict):
    euid = event.get('euid')
    cam_key = event.get('cam_key')
    if Globals.frame_hold_queue1:                    
        # Capture current frame and send put it to fast upload queue
        frame = Globals.frame_hold_queue1[-1]
                
        event_message = {
            "topic": current_topic,
            "module": "IDS",
            "action": "intrusion_shots",
            "target": "MQTT",
            "payload": {
                "eUID": euid,
                "frame": frame,
                "deviceInstanceId": cam_key,
                "file_urls": []
                }
            }
        
        Globals.fast_upload_queue.put(event_message)
        print(f'Globals.fast_upload_queue: {Globals.fast_upload_queue.qsize()}')
        
    if euid not in Globals.ongoing_post_events1:
        event_message = {
            "topic": current_topic,
            "module": "IDS",
            "action": "intrusion_shots",
            "target": "MQTT",
            "payload": {
                "eUID": euid,
                "deviceInstanceId": cam_key,
                "start_time": time.time(),
                "frames": [frame for _, frame in Globals.pre_event_frames1]
                }
            }
        Globals.ongoing_post_events1[euid] = event_message

def capture_and_send_upload_signal2(event: dict):
    euid = event.get('euid')
    cam_key = event.get('cam_key')
    if Globals.frame_hold_queue2:                    
        # Capture current frame and send put it to fast upload queue
        frame = Globals.frame_hold_queue2[-1]
                
        event_message = {
            "topic": current_topic,
            "module": "IDS",
            "action": "intrusion_shots",
            "target": "MQTT",
            "payload": {
                "eUID": euid,
                "frame": frame,
                "deviceInstanceId": cam_key,
                "file_urls": []
                }
            }
        
        Globals.fast_upload_queue.put(event_message)
        print(f'Globals.fast_upload_queue: {Globals.fast_upload_queue.qsize()}')
        
    if euid not in Globals.ongoing_post_events2:
        event_message = {
            "topic": current_topic,
            "module": "IDS",
            "action": "intrusion_shots",
            "target": "MQTT",
            "payload": {
                "eUID": euid,
                "deviceInstanceId": cam_key,
                "start_time": time.time(),
                "frames": [frame for _, frame in Globals.pre_event_frames2]
                }
            }
        Globals.ongoing_post_events2[euid] = event_message
