import time, uuid
import json
from datetime import datetime, timezone, timedelta
from collections import defaultdict

from utility_service import Globals
from config_service import load_default_config
from enums import SirenAction, RelayAction


# Default Configuration
config = load_default_config()
TOPIC_EVENTS = config.get("mqtt_topic_events", '')
DIRECTORY_NAME_CAMERA_CAPTURE = config.get('directory_name_camera_capture', '')
DEVICE_DISARMED_MODE = config.get('device_disarmed_mode')
DEVICE_ARMED_MODE = config.get('device_armed_mode')

def decision_worker1(cam_key):
    print(f"""[decision_worker1]
                   Camera ID         : {cam_key}
                   Index             : {Globals.cam_key_idx_map[cam_key]}
                   scene_map         : {Globals.scene_map1}
                   all_labels_set    : {Globals.all_labels_set1}
                   schedule_map      : {Globals.schedule_map1}
                   camera mode       : {Globals.cam_mode_map[cam_key]}
    """)
    
    scene_map = Globals.scene_map1

    # Data structure to track valid detection counts per label per bucket
    label_buckets = defaultdict(lambda: defaultdict(list))
    
     # Track active events per label (e.g., whether an event is ongoing for 'person')
    active_events = defaultdict(bool)
    
    # Map each active label to a unique UUID for event tracking
    incident_ids = defaultdict(str)
    
    while True:
        # Step 1: Drain the detection queue and populate the bucket structure
        while len(Globals.detection_queue1) > 0:
            entry = Globals.detection_queue1.popleft()
            pts = entry['pts']
            detections = entry['detections']
            #print(detections)
            ###
            # Maps a timestamp (pts) in nanoseconds to the start of its corresponding fixed-size time bucket.
            # For example, with BUCKET_SIZE_NS = 500_000_000:
            # - pts = 1_150_000_000 → bucket = 1_000_000_000
            # - pts = 2_480_000_000 → bucket = 2_000_000_000
            ###
            bkt = bucket_start(pts) # Calculate / find the time bucket
            
             # Iterate through each detection in the entry
            #for label, conf in [(k, v) for k, v in detections.items() if not k.endswith('_count')]:
            labels = [k for k in detections.keys() if not (k.endswith('_count') or k.endswith('_bbox'))]
            for label in labels:
                conf = detections[label]
                bbox = detections.get(f"{label}_bbox")
                scene_instance_id = get_scene_instance_id_by_label(label, scene_map)
                schedule_map = Globals.schedule_map1.get(scene_instance_id)
                _, _, areaName, floorType, deviceName, sceneName, siren_ip, siren_port, is_enable_siren  = schedule_map
                is_scheduled = is_within_schedule(schedule_map, cam_key)
                if not is_scheduled:
                    print('Curent time is not scheulded to proceed with detections.')
                    time.sleep(1)
                    break
                    
                is_intruding = is_overlapping(schedule_map, bbox)

                label_buckets[label].setdefault(bkt, 0) # Initialize bucket count
                if is_intruding and conf >= Globals.MIN_CONFIDENCE:
                    # print(f"label_buckets {is_scheduled}")
                    # Count valid detections for this label in the current bucket
                    label_buckets[label][bkt] += 1
                
                # Step 2: Evaluate event start and end conditions
            for label in list(label_buckets.keys()):
                # print(f"Bucket key :::: {label}")
                bucket_flags = label_buckets[label] # {bucket_time: count}
                sorted_bkts = sorted(bucket_flags.keys()) # Process in chronological order

                # Check for event start conditions
                for i in range(len(sorted_bkts)):
                    # print(f"Sorted Bucket ::: {i}")
                    bkt = sorted_bkts[i]
                    current_val = bucket_flags[bkt]
                    
                    # Single bucket has enough valid detections
                    if current_val >= Globals.MIN_OCCURRENCES:
                        # print(f"Valid Detection ::: {current_val}")
                        if not active_events[label]:
                            # print(f"Valid Detection Condition pass ::: {current_val}")
                            uid = str(uuid.uuid4())
                            active_events[label] = True
                            incident_ids[label] = uid
                            # Publish the Start Event
                            if is_enable_siren:
                               Globals.relay_queue.put((siren_ip, siren_port, RelayAction.ON)) 
                            else:
                                print("[SIREN] Siren disabled in config, skipping ON command")                         
                            uid, euid, current_topic = publishEvent('intrusion_event', cam_key, incident_ids, label, scene_instance_id, areaName, floorType, deviceName, sceneName, conf)
                            Globals.capture_frame_queue1.put({'cam_key': cam_key, 'euid': euid, 'file_path': DIRECTORY_NAME_CAMERA_CAPTURE, 'current_topic': current_topic, 'event_topic': TOPIC_EVENTS})
                            print(f"🟢 decision_worker1 Event Start: {{ camera_id: {cam_key}, uid: {uid}, label: '{label}', bucket: {bkt}, scene_instance_id: {scene_instance_id} }}")
                        break # Start event only once
                    
                    # Two consecutive buckets have minimal valid detections each
                    elif i + 1 < len(sorted_bkts):
                        next_val = bucket_flags[sorted_bkts[i+1]]
                        if current_val == Globals.MIN_OCCURRENCES_BETWEEN_TWO_BUCKETS and next_val == Globals.MIN_OCCURRENCES_BETWEEN_TWO_BUCKETS:
                            if not active_events[label]:
                                # print(f"Valid Detection Else Condition pass ::: {current_val}")
                                uid = str(uuid.uuid4())
                                active_events[label] = True
                                incident_ids[label] = uid
                                scene_instance_id = get_scene_instance_id_by_label(label, scene_map)
                                # Publish the Start Event
                                # Globals.siren_queue.put(SirenAction.ON)
                                if is_enable_siren:
                                    Globals.relay_queue.put((siren_ip, siren_port, RelayAction.ON)) 
                                else:
                                    print("[SIREN] Siren disabled in config, skipping ON command")
                                uid, euid, current_topic = publishEvent('intrusion_event', cam_key, incident_ids, label, scene_instance_id, areaName, floorType, deviceName, sceneName, conf)
                                Globals.capture_frame_queue1.put({'cam_key': cam_key, 'euid': euid, 'file_path': DIRECTORY_NAME_CAMERA_CAPTURE, 'current_topic': current_topic, 'event_topic': TOPIC_EVENTS})
                                print(f"🟢 decision_worker1 Event Start: {{ camera_id: {cam_key}, uid: {uid}, label: '{label}', buckets: [{bkt}, scene_instance_id: {scene_instance_id}] }}")
                            break # Start event only once

                # Check for event end conditions
                if active_events[label]:
                    # print(f"event end conditions ::: {label}")
                    # Look at the last N buckets to determine if detections have stopped
                    trailing = list(bucket_flags.items())[-Globals.EMPTY_BUCKET_GRACE:]
                    if len(trailing) == Globals.EMPTY_BUCKET_GRACE and all(val == 0 for _, val in trailing):
                        # print("Event end contiion")
                        # Publish the End Event
                        if is_enable_siren:
                            Globals.relay_queue.put((siren_ip, siren_port, RelayAction.OFF)) 
                            print(f"[SIREN] Siren enabled, turning OFF (IP={siren_ip}, PORT={siren_port})")
                        else:
                            print("[SIREN] Siren disabled in config, skipping OFF command")
                        uid, euid, current_topic = publishEvent('intrusion_event_end', cam_key, incident_ids, label, scene_instance_id, areaName, floorType, deviceName, sceneName, conf)
                        print(f"🔴 decision_worker1 Event End:   {{ camera_id: {cam_key}, uid: {uid}, label: '{label}' }}")
                        active_events[label] = False
                        incident_ids[label] = ""

                # Prune old buckets beyond the EMPTY_BUCKET_GRACE window
                if len(sorted_bkts) > Globals.EMPTY_BUCKET_GRACE:
                    # print(f"Empty Bucket Deleted ::: {len(sorted_bkts)}")
                    for old_bkt in sorted_bkts[:-Globals.EMPTY_BUCKET_GRACE]:
                        del label_buckets[label][old_bkt]
                        
        # Small sleep to avoid CPU overload in tight loop
        time.sleep(0.01)

def publishEvent(action, cam_key, incident_ids, label, scene_instance_id, areaName, floorType, deviceName, sceneName, confidenceLevel):
    uid = incident_ids[label]
    from mqtt_service import publish, get_current_topic
    euid = f"{cam_key}-{uid}"
    current_topic = get_current_topic()
    device_timezone = str(Globals.device_timezone)
    detection_data = {
                    "topic": current_topic,
                    "module": "IDS",
                    "action": action,
                    "target": "MQTT",
                    "payload": {
                        "eUID": euid,
                        "deviceInstanceId": cam_key,
                        "sceneInstanceId": scene_instance_id,
                        "areaName": areaName,
                        "floorType": floorType,
                        "deviceName": deviceName,
                        "sceneName": sceneName,
                        "activity": label,
                        "confidenceLevel": confidenceLevel,
                        "intrusionStartDateTime": datetime.now(timezone.utc).isoformat(),
                        "timezone": device_timezone
                        }
                    }
    publish(TOPIC_EVENTS, json.dumps(detection_data), qos=1, retain=False)
    return uid,euid,current_topic
        
# Utility to convert a timestamp (pts) into its corresponding bucket start
BUCKET_SIZE_NS = Globals.WINDOW_MS * 1_000_000
def bucket_start(pts):
    return (pts // BUCKET_SIZE_NS) * BUCKET_SIZE_NS
    
def get_scene_instance_id_by_label(label, scene_map):
    if not scene_map:
        return None
    for scene_id, labels in scene_map.items():
        if label in labels:
            return scene_id
    return None

def is_overlapping(schedule_map, current_bbox):
    _, roi_box, *_ = schedule_map

    if not current_bbox:
        return True # Consider full frame if ROI not defined!

    try:
        # Calculate the intersection box
        x_left = max(current_bbox['xmin'], roi_box['x1'])
        y_top = max(current_bbox['ymin'], roi_box['y1'])
        x_right = min(current_bbox['xmax'], roi_box['x2'])
        y_bottom = min(current_bbox['ymax'], roi_box['y2'])

        # If no overlap
        if x_right <= x_left or y_bottom <= y_top:
            return False

        # Area calculations
        intersection_area = (x_right - x_left) * (y_bottom - y_top)
        bbox_area = (current_bbox['xmax'] - current_bbox['xmin']) * (current_bbox['ymax'] - current_bbox['ymin'])

        # Trigger intrusion only if 50% or more of the object is inside the ROI
        return intersection_area >= 0.5 * bbox_area

    except KeyError:
        return False
    
def is_within_schedule(schedule_map, cam_key):
    mode = Globals.cam_mode_map.get(cam_key, DEVICE_ARMED_MODE)
    if mode == DEVICE_DISARMED_MODE:
        print("Device disarmed")
        return False

    if not schedule_map:
        print("Do not process, there is no schedule available")
        return False

    now_utc = datetime.now(timezone.utc)
    current_weekday = now_utc.weekday()  # Monday=0 ... Sunday=6

    schedules, *_ = schedule_map

    day_schedules = schedules.get(str(current_weekday), [])
    if not day_schedules:
        return False

    for schedule in day_schedules:
        start_time_str = schedule["startTime"]
        end_time_str = schedule["endTime"]

        start_hour, start_minute = map(int, start_time_str.split(":"))
        end_hour, end_minute = map(int, end_time_str.split(":"))

        today_start_dt = now_utc.replace(hour=start_hour, minute=start_minute, second=0, microsecond=0)
        today_end_dt = now_utc.replace(hour=end_hour, minute=end_minute, second=0, microsecond=0)

        # Handle overnight span
        if today_end_dt <= today_start_dt:
            # Overnight, so end time is next day
            if now_utc <= today_end_dt:
                start_dt = today_start_dt - timedelta(days=1)
                end_dt = today_end_dt
            else:
                start_dt = today_start_dt
                end_dt = today_end_dt + timedelta(days=1)
        else:
            start_dt = today_start_dt
            end_dt = today_end_dt

        if start_dt <= now_utc <= end_dt:
            return True

    return False
